#pragma once
#include <tuple>
#include <string>
#include <utility>

template<typename T>
struct Reflector;

struct ExampleData {
    std::string name;
    int count;
};

template<>
struct Reflector<ExampleData> {
    static constexpr auto fields = std::make_tuple(
        std::make_pair("name", &ExampleData::name),
        std::make_pair("count", &ExampleData::count)
    );
};
