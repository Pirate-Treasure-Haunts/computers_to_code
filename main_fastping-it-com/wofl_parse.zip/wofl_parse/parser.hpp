#pragma once
#include "Tokenizer.hpp"
#include "Reflector.hpp"
#include <string>
#include <iostream>

template<typename T>
class Parser {
public:
    Parser(std::string_view src) : tokenizer(src) {}

    bool parse(T& out);

private:
    Tokenizer tokenizer;

    bool parseObject(T& out);
};
