#include <immintrin.h>
#include <cstddef>
#include <cstdint>

// Whitespace chars in JSON
static inline __m256i whitespace_mask() {
    return _mm256_setr_epi8(
        ' ', '\n', '\r', '\t',    // add more if needed
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    );
}

// Check if byte is whitespace (set 0xFF for ws)
inline __m256i is_whitespace(__m256i block) {
    __m256i spaces = _mm256_cmpeq_epi8(block, _mm256_set1_epi8(' '));
    __m256i tabs   = _mm256_cmpeq_epi8(block, _mm256_set1_epi8('\t'));
    __m256i nl     = _mm256_cmpeq_epi8(block, _mm256_set1_epi8('\n'));
    __m256i cr     = _mm256_cmpeq_epi8(block, _mm256_set1_epi8('\r'));
    return _mm256_or_si256(_mm256_or_si256(spaces, tabs), _mm256_or_si256(nl, cr));
}

// Core: copy non-whitespace, outside string, to dst
size_t minify_json_avx2(const char* src, size_t len, char* dst) {
    size_t src_pos = 0, dst_pos = 0;
    bool in_string = false;
    bool prev_escape = false;

    while (src_pos + 32 <= len) {
        __m256i block = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(src + src_pos));

        // Track string state *per block* (does NOT handle escapes inside strings, see below for scalar fallback)
        __m256i quotes = _mm256_cmpeq_epi8(block, _mm256_set1_epi8('\"'));

        // Build whitespace mask
        __m256i ws_mask = is_whitespace(block);

        // Compute "keep" mask: bytes to keep (not ws or inside string)
        uint32_t quote_bits = _mm256_movemask_epi8(quotes);
        // (Naive: toggle in_string for each quote; advanced: use prefix xor for state per byte)
        for (int i = 0; i < 32; ++i) {
            char c = src[src_pos + i];
            // Scalar fallback for correctness
            if (c == '\"' && !prev_escape) in_string = !in_string;
            if (c == '\\' && in_string) prev_escape = !prev_escape;
            else prev_escape = false;
            bool is_ws = (c == ' ' || c == '\t' || c == '\r' || c == '\n');
            if (!is_ws || in_string) {
                dst[dst_pos++] = c;
            }
        }
        src_pos += 32;
    }

    // Handle remaining scalar bytes
    bool prev_escape = false;
    while (src_pos < len) {
        char c = src[src_pos++];
        if (c == '\"' && !prev_escape) in_string = !in_string;
        if (c == '\\' && in_string) prev_escape = !prev_escape;
        else prev_escape = false;
        bool is_ws = (c == ' ' || c == '\t' || c == '\r' || c == '\n');
        if (!is_ws || in_string) {
            dst[dst_pos++] = c;
        }
    }
    return dst_pos;
}
