#include "Tokenizer.hpp"
#include <cctype>

void Tokenizer::skipWhitespace() {
    while (pos < source.size() && std::isspace(source[pos])) pos++;
}

Token Tokenizer::next() {
    skipWhitespace();
    if (pos >= source.size()) return { TokenType::End, {} };

    char c = source[pos];
    switch (c) {
    case '{': pos++; return { TokenType::ObjectStart, "{" };
    case '}': pos++; return { TokenType::ObjectEnd, "}" };
    case '[': pos++; return { TokenType::ArrayStart, "[" };
    case ']': pos++; return { TokenType::ArrayEnd, "]" };
    case ':': pos++; return { TokenType::Colon, ":" };
    case ',': pos++; return { TokenType::Comma, "," };
    case '"': return parseString();
    case 't': case 'f': case 'n': return parseKeyword();
    default:  return parseNumber();
    }
}

Token Tokenizer::parseString() {
    size_t start = ++pos;
    while (pos < source.size() && source[pos] != '"') pos++;
    size_t end = pos++;
    return { TokenType::String, source.substr(start, end - start) };
}

Token Tokenizer::parseNumber() {
    size_t start = pos;
    while (pos < source.size() && (std::isdigit(source[pos]) || source[pos] == '.' || source[pos] == '-')) pos++;
    return { TokenType::Number, source.substr(start, pos - start) };
}

Token Tokenizer::parseKeyword() {
    size_t start = pos;
    while (pos < source.size() && std::isalpha(source[pos])) pos++;
    std::string_view kw = source.substr(start, pos - start);
    if (kw == "true" || kw == "false") return { TokenType::Bool, kw };
    if (kw == "null") return { TokenType::Null, kw };
    return { TokenType::End, {} };  // crude fallback
}
