#pragma once
#include <string_view>
#include <vector>

enum class TokenType {
    String, Number, Bool, Null,
    ObjectStart, ObjectEnd,
    ArrayStart, ArrayEnd,
    Colon, Comma,
    End
};

struct Token {
    TokenType type;
    std::string_view value;  // Points into source buffer
};

class Tokenizer {
public:
    Tokenizer(std::string_view src) : source(src), pos(0) {}

    Token next();

private:
    std::string_view source;
    size_t pos;

    void skipWhitespace();
    Token parseString();
    Token parseNumber();
    Token parseKeyword();  // true, false, null
};
