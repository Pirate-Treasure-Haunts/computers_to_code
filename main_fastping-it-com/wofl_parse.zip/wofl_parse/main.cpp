#include "ArrayParser.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <thread>
#include <chrono>

std::string runCommand(const char* cmd) {
    char buffer[256];
    std::string result;
    FILE* pipe = _popen(cmd, "r");
    if (!pipe) return "";
    while (fgets(buffer, sizeof(buffer), pipe)) {
        result += buffer;
    }
    _pclose(pipe);
    return result;
}

int main() {
    while (true) {
        std::string json = runCommand("curl http://127.0.0.1:5000/ping");

        std::vector<std::string> lines;
        ArrayParser parser(json);

        if (parser.parse(lines)) {
            std::cout << "---- Received Response ----\n";
            for (const auto& line : lines) {
                std::cout << line << "\n";
            }
        } else {
            std::cout << "Failed to parse JSON response!\n";
        }

        std::this_thread::sleep_for(std::chrono::seconds(10));
    }
}
