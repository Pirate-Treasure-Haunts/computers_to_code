How It Works
✅ Hits http://127.0.0.1:5000/ping every 10 seconds
✅ Parses the JSON array from your server
✅ Prints each line of the response
✅ Runs in an infinite loop — your basic beacon